import { GoogleGenAI, Modality } from "@google/genai";
import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "15mb" }));

// Initialize GenAI helper
const getAi = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

// Health Check
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", geminiAvailable: !!process.env.GEMINI_API_KEY });
});

// Endpoint: Generate Legacy Video/Audio Script
app.post("/api/gemini/legacy-script", async (req, res) => {
  try {
    const { beneficiaryName, relationship, memories, tone, wishList, specificInstructions } = req.body;
    const ai = getAi();

    if (!ai) {
      // Fallback response if no API key
      return res.json({
        script: `Dearest ${beneficiaryName || "loved one"},\n\nIf you are reading or watching this message, it means my journey on earth has come to a peaceful close. I wanted to leave you with words from my heart that time could never erase.\n\n${
          memories ? `I will cherish forever our memories together: ${memories}.` : "Always remember the laughter and moments we shared."
        }\n\n${
          wishList ? `My wish for you: ${wishList}.` : "Live your life fully, with kindness, courage, and joy."
        }\n\nAll my love always,\nYour ${relationship || "Family Member"}`,
        emotionalTone: tone || "Heartfelt & Uplifting",
        suggestedVisuals: [
          "Fade in with warm sunlight filtering through leaves",
          "Display album photo from summer trip",
          "Soft acoustic piano melody playing in background",
          "Closing frame with handwritten signature"
        ],
        source: "fallback"
      });
    }

    const prompt = `You are an empathetic digital legacy writer helping a user write a final posthumous message and video script for their ${relationship || "loved one"}, named ${beneficiaryName || "Dearly Beloved"}.
Tone: ${tone || "Heartfelt, comforting, clear, and inspiring"}.
Memories shared: ${memories || "Many happy moments together"}.
Personal wishes or advice: ${wishList || "Be happy, care for each other"}.
Specific instructions: ${specificInstructions || "None"}.

Output JSON format:
{
  "script": "Full narrative text to be spoken or read aloud",
  "emotionalTone": "Detailed description of mood",
  "suggestedVisuals": ["List of 3-4 visual cues or memory photos to overlay in video"],
  "closingThought": "A memorable final sentence"
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json({ ...parsed, source: "gemini" });
  } catch (error: any) {
    console.error("Error in /api/gemini/legacy-script:", error);
    res.status(500).json({ error: error.message || "Failed to generate script" });
  }
});

// Endpoint: Text to Speech preview for Legacy Video
app.post("/api/gemini/legacy-tts", async (req, res) => {
  try {
    const { text, voiceName } = req.body;
    const ai = getAi();

    if (!ai) {
      return res.status(400).json({ error: "Gemini API key not available for TTS" });
    }

    const voice = voiceName || "Kore"; // 'Puck', 'Charon', 'Kore', 'Fenrir', 'Zephyr'
    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-tts-preview",
      contents: [{ parts: [{ text: `Say with warmth and calm emotion: ${text.slice(0, 400)}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      res.json({ audioBase64: base64Audio, mimeType: "audio/pcm;rate=24000" });
    } else {
      res.status(500).json({ error: "No audio data received from Gemini" });
    }
  } catch (error: any) {
    console.error("Error in /api/gemini/legacy-tts:", error);
    res.status(500).json({ error: error.message || "TTS generation failed" });
  }
});

// Endpoint: Generate Subscription Cancellation Letter
app.post("/api/gemini/subscription-notice", async (req, res) => {
  try {
    const { serviceName, accountEmail, accountNumber, executorName } = req.body;
    const ai = getAi();

    if (!ai) {
      return res.json({
        noticeText: `OFFICIAL POSTHUMOUS SUBSCRIPTION CANCELLATION REQUEST\n\nTo: ${serviceName} Legal & Billing Support\nDate: [Date of Activation]\nSubject: Termination of Account & Billing - ${accountEmail}\n\nThis document serves as formal notification that the account holder associated with ${accountEmail} (Ref: ${accountNumber || "N/A"}) has passed away.\n\nAs the designated Digital Estate Executor (${executorName || "Authorized Trustee"}), I hereby request immediate termination of all active subscriptions, recurring billing cycles, and payment methods linked to this account.\n\nPlease confirm cancellation and zero remaining balance via return receipt. Attached is the encrypted Digital Will Vault authorization token.\n\nSincerely,\n${executorName || "Digital Will Executor"}`,
        source: "fallback"
      });
    }

    const prompt = `Draft a formal, legal posthumous account cancellation and subscription termination request letter to ${serviceName}.
Account Email: ${accountEmail}
Account Ref ID: ${accountNumber || "N/A"}
Executor Name: ${executorName || "Digital Estate Executor"}

Keep it concise, authoritative, respectful, and legally clear to prevent ongoing family billing. Output JSON with property "noticeText".`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json({ ...parsed, source: "gemini" });
  } catch (error: any) {
    console.error("Error in /api/gemini/subscription-notice:", error);
    res.status(500).json({ error: error.message || "Failed to generate cancellation notice" });
  }
});

// Endpoint: MPC Cryptographic Security Audit & Shard Analysis
app.post("/api/gemini/mpc-analysis", async (req, res) => {
  try {
    const { totalShards, threshold, assetType, label } = req.body;
    const ai = getAi();

    if (!ai) {
      return res.json({
        securityLevel: "Institutional Multi-Party Computation (Threshold Cryptography)",
        summary: `Using Shamir's Secret Sharing over Galois Field GF(2^256), your ${label} (${assetType}) is mathematically divided into ${totalShards} distributed key shards.`,
        recoveryScenario: `No individual key holder can view or recreate the key. When the Dead Man's Switch activates, any ${threshold} out of ${totalShards} trustees can combine their shards to perform Lagrange interpolation, reconstructing the master key safely.`,
        threatModel: "Resistant to single-point compromise, server breach, or rogue trustee theft.",
        source: "fallback"
      });
    }

    const prompt = `Provide a short mathematical security audit explanation for an MPC key sharding policy of threshold ${threshold}-of-${totalShards} for asset "${label}" (${assetType}).
Output JSON:
{
  "securityLevel": "Title string",
  "summary": "Technical explanation of zero-knowledge polynomial threshold sharing",
  "recoveryScenario": "Description of how the ${threshold} trustees assemble shards",
  "threatModel": "Summary of cryptographic resistance"
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json({ ...parsed, source: "gemini" });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "MPC analysis failed" });
  }
});

// Start Express + Vite
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Digital Will Vault server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
