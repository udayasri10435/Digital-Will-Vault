import React, { useState } from 'react';
import { Sparkles, Play, Volume2, VolumeX, Plus, Heart, User, Image, Film, Music, Check, RefreshCw, FileText } from 'lucide-react';
import { LegacyCapsule } from '../types';

interface LegacyCapsulesProps {
  capsules: LegacyCapsule[];
  isActivated: boolean;
  onAddCapsule: (capsule: LegacyCapsule) => void;
  onAuditLog: (msg: string, type: 'CHECK_IN' | 'SECRET_UNLOCKED') => void;
}

export const LegacyCapsules: React.FC<LegacyCapsulesProps> = ({
  capsules,
  isActivated,
  onAddCapsule,
  onAuditLog,
}) => {
  const [activeVideoModalCapsule, setActiveVideoModalCapsule] = useState<LegacyCapsule | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [isGeneratingScript, setIsGeneratingScript] = useState<boolean>(false);
  const [isGeneratingTts, setIsGeneratingTts] = useState<boolean>(false);
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);

  // New capsule form state
  const [beneficiaryName, setBeneficiaryName] = useState('');
  const [relationship, setRelationship] = useState('Daughter');
  const [beneficiaryEmail, setBeneficiaryEmail] = useState('');
  const [memories, setMemories] = useState('');
  const [personalWishes, setPersonalWishes] = useState('');
  const [tone, setTone] = useState('Warm, Heartfelt & Comforting');
  const [voiceName, setVoiceName] = useState('Kore');
  const [photoUrl, setPhotoUrl] = useState('https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&w=800&q=80');

  // Preview generated content in compose modal
  const [generatedScriptPreview, setGeneratedScriptPreview] = useState<string>('');
  const [visualCuesPreview, setVisualCuesPreview] = useState<string[]>([]);
  const [audioBase64Preview, setAudioBase64Preview] = useState<string>('');

  const handleGenerateScriptWithGemini = async () => {
    if (!beneficiaryName || !memories) return;
    setIsGeneratingScript(true);

    try {
      const res = await fetch('/api/gemini/legacy-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          beneficiaryName,
          relationship,
          memories,
          tone,
          wishList: personalWishes
        })
      });
      const data = await res.json();
      setGeneratedScriptPreview(data.script || '');
      setVisualCuesPreview(data.suggestedVisuals || []);

      // If script generated, try generating TTS preview
      if (data.script) {
        handleGenerateTtsAudio(data.script);
      }
    } catch (err) {
      console.error('Error generating script:', err);
    } finally {
      setIsGeneratingScript(false);
    }
  };

  const handleGenerateTtsAudio = async (text: string) => {
    setIsGeneratingTts(true);
    try {
      const res = await fetch('/api/gemini/legacy-tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, voiceName })
      });
      const data = await res.json();
      if (data.audioBase64) {
        setAudioBase64Preview(data.audioBase64);
      }
    } catch (err) {
      console.error('Error generating TTS:', err);
    } finally {
      setIsGeneratingTts(false);
    }
  };

  const handleCreateCapsuleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!beneficiaryName) return;

    const newCapsule: LegacyCapsule = {
      id: 'capsule-' + Date.now(),
      beneficiaryName,
      relationship,
      beneficiaryEmail,
      memories,
      personalWishes,
      tone,
      voiceName,
      photoUrl,
      generatedScript: generatedScriptPreview || `Dearest ${beneficiaryName},\n\nIf you are reading or watching this message, know that my journey on earth has come to a peaceful close. Remember the laughter and moments we shared: ${memories}.\n\nMy wish for you: ${personalWishes || "Live with joy and courage."}\n\nAll my love always,`,
      visualCues: visualCuesPreview.length > 0 ? visualCuesPreview : [
        'Fade in memory photo with warm ambient lighting',
        'Soft string instrument acoustic melody',
        'Handwritten letter closing'
      ],
      audioBase64: audioBase64Preview,
      isUnlocked: false,
      createdAt: new Date().toISOString()
    };

    onAddCapsule(newCapsule);
    onAuditLog(`New AI Legacy Capsule created for ${beneficiaryName} (${relationship}). Script & Voice narration compiled.`, 'CHECK_IN');

    // Reset
    setShowCreateModal(false);
    setBeneficiaryName('');
    setMemories('');
    setPersonalWishes('');
    setGeneratedScriptPreview('');
    setAudioBase64Preview('');
  };

  const handlePlayCapsuleAudio = (capsule: LegacyCapsule) => {
    if (isPlayingAudio && audioElement) {
      audioElement.pause();
      setIsPlayingAudio(false);
      return;
    }

    if (capsule.audioBase64) {
      // Play raw PCM audio or data url
      const audio = new Audio(`data:audio/wav;base64,${capsule.audioBase64}`);
      audio.play().then(() => {
        setIsPlayingAudio(true);
        setAudioElement(audio);
      }).catch((e) => console.log('Audio playback preview:', e));

      audio.onended = () => setIsPlayingAudio(false);
    } else {
      // Fallback browser speech synthesis for preview
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(capsule.generatedScript || capsule.memories);
        utterance.rate = 0.9;
        utterance.pitch = 1.0;
        utterance.onend = () => setIsPlayingAudio(false);
        window.speechSynthesis.speak(utterance);
        setIsPlayingAudio(true);
      }
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-purple-400 text-xs font-semibold uppercase tracking-wider">
            <Sparkles className="w-4 h-4" />
            <span>AI Storyteller & Memory Capsules</span>
          </div>
          <h2 className="text-xl font-bold text-white font-serif">Posthumous AI Video & Voice Messages</h2>
          <p className="text-xs text-slate-400 max-w-2xl">
            Store photos, voice notes, and favorite memories. Gemini AI crafts heartfelt posthumous video scripts and synthesizes spoken voice narration so your family hears your voice and love even after you pass.
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="bg-purple-600 hover:bg-purple-500 text-white px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-purple-950/40"
        >
          <Plus className="w-4 h-4" />
          <span>Compose Legacy Capsule</span>
        </button>
      </div>

      {/* Capsules Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {capsules.map((capsule) => (
          <div
            key={capsule.id}
            className="bg-slate-900 border border-slate-800 hover:border-purple-500/40 rounded-2xl overflow-hidden shadow-xl transition-all group flex flex-col justify-between"
          >
            {/* Top Photo & Video Thumbnail Overlay */}
            <div className="relative h-48 bg-slate-950 overflow-hidden">
              <img
                src={capsule.photoUrl || 'https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&w=800&q=80'}
                alt={capsule.beneficiaryName}
                className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent" />

              {/* Status Badge */}
              <div className="absolute top-3 left-3 flex items-center gap-2">
                <span className={`px-2.5 py-1 rounded-full text-[10px] font-mono font-bold tracking-wider ${
                  isActivated || capsule.isUnlocked
                    ? 'bg-emerald-500 text-slate-950 shadow-md'
                    : 'bg-slate-900/80 text-amber-300 border border-amber-500/30'
                }`}>
                  {isActivated || capsule.isUnlocked ? 'UNLOCKED FOR BENEFICIARY' : 'ENCRYPTED IN VAULT'}
                </span>
              </div>

              {/* Play Video Trigger Button */}
              <div className="absolute inset-0 flex items-center justify-center">
                <button
                  onClick={() => setActiveVideoModalCapsule(capsule)}
                  className="w-14 h-14 rounded-full bg-purple-600/90 hover:bg-purple-500 text-white flex items-center justify-center shadow-xl shadow-purple-950/80 transition-transform group-hover:scale-110 cursor-pointer"
                  title="Play AI Generated Video Tribute"
                >
                  <Play className="w-6 h-6 ml-1 fill-white" />
                </button>
              </div>

              {/* Beneficiary Badge Bottom Left */}
              <div className="absolute bottom-3 left-4">
                <div className="text-xs text-purple-300 font-mono">For {capsule.relationship}</div>
                <h3 className="text-lg font-bold text-white font-serif">{capsule.beneficiaryName}</h3>
              </div>
            </div>

            {/* Content Body */}
            <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
              <div className="space-y-2">
                <div className="text-xs text-slate-300 italic line-clamp-3 bg-slate-950 p-3 rounded-xl border border-slate-800/80">
                  "{capsule.generatedScript || capsule.memories}"
                </div>

                {capsule.visualCues && capsule.visualCues.length > 0 && (
                  <div className="space-y-1">
                    <span className="text-[10px] font-mono uppercase text-slate-400">Visual Memory Overlay Cues:</span>
                    <ul className="text-[11px] text-slate-400 space-y-0.5 list-disc list-inside">
                      {capsule.visualCues.slice(0, 2).map((cue, i) => (
                        <li key={i} className="truncate">{cue}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Bottom Actions Row */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-slate-400 font-mono text-[11px]">
                  <Music className="w-3.5 h-3.5 text-purple-400" />
                  <span>Voice: {capsule.voiceName}</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handlePlayCapsuleAudio(capsule)}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-purple-300 border border-purple-500/30 flex items-center gap-1.5 cursor-pointer font-semibold"
                  >
                    {isPlayingAudio ? <VolumeX className="w-3.5 h-3.5 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5 text-purple-400" />}
                    <span>{isPlayingAudio ? 'Stop' : 'Listen Audio'}</span>
                  </button>

                  <button
                    onClick={() => setActiveVideoModalCapsule(capsule)}
                    className="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-bold flex items-center gap-1.5 cursor-pointer shadow-md"
                  >
                    <Film className="w-3.5 h-3.5" />
                    <span>Watch Video</span>
                  </button>
                </div>
              </div>

            </div>
          </div>
        ))}
      </div>

      {/* Video Tribute Modal */}
      {activeVideoModalCapsule && (
        <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-purple-500/30 rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl space-y-0 animate-scaleUp">
            
            {/* Simulated Video Player Box */}
            <div className="relative aspect-video bg-black flex items-center justify-center overflow-hidden">
              <img
                src={activeVideoModalCapsule.photoUrl || 'https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&w=800&q=80'}
                alt="Memory Tribute"
                className="w-full h-full object-cover opacity-70 animate-pulse"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-slate-950/60" />

              {/* Scrolling Teleprompter Text overlay */}
              <div className="absolute bottom-6 left-6 right-6 p-4 bg-slate-950/80 backdrop-blur-sm rounded-xl border border-purple-500/30 text-center space-y-2">
                <span className="text-[10px] font-mono text-purple-400 uppercase tracking-widest">
                  AI Narration • Voice: {activeVideoModalCapsule.voiceName}
                </span>
                <p className="text-sm md:text-base font-serif text-white leading-relaxed italic">
                  "{activeVideoModalCapsule.generatedScript}"
                </p>
              </div>

              {/* Top Banner */}
              <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                <div className="flex items-center gap-2 px-3 py-1 bg-slate-950/80 rounded-full border border-purple-500/40 text-xs font-bold text-white">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  <span>Legacy Video Tribute for {activeVideoModalCapsule.beneficiaryName}</span>
                </div>
                <button
                  onClick={() => {
                    setActiveVideoModalCapsule(null);
                    if (window.speechSynthesis) window.speechSynthesis.cancel();
                  }}
                  className="w-8 h-8 rounded-full bg-slate-950/80 hover:bg-slate-800 text-white flex items-center justify-center font-bold text-sm cursor-pointer"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Video Controls Footer */}
            <div className="p-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between">
              <div className="text-xs text-slate-400 font-mono">
                Tone: <strong className="text-purple-300">{activeVideoModalCapsule.tone}</strong>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => handlePlayCapsuleAudio(activeVideoModalCapsule)}
                  className="bg-purple-600 hover:bg-purple-500 text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer shadow-lg"
                >
                  {isPlayingAudio ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  <span>{isPlayingAudio ? 'Pause Spoken Audio' : 'Play Spoken Voice'}</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Modal: Compose New Legacy Capsule */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-lg w-full shadow-2xl space-y-4 animate-scaleUp max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white font-serif flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-400" />
                Compose AI Legacy Capsule
              </h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-white text-lg font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateCapsuleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Beneficiary Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Sophia Vance"
                    value={beneficiaryName}
                    onChange={(e) => setBeneficiaryName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Relationship</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Daughter, Spouse, Sister"
                    value={relationship}
                    onChange={(e) => setRelationship(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Shared Memories & Moments</label>
                <textarea
                  required
                  rows={2}
                  placeholder="Describe special trips, jokes, graduation days, or favorite places together..."
                  value={memories}
                  onChange={(e) => setMemories(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-200 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Personal Wishes & Advice</label>
                <textarea
                  rows={2}
                  placeholder="What do you wish for their future? Advice on life, happiness, or love..."
                  value={personalWishes}
                  onChange={(e) => setPersonalWishes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-200 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Gemini AI Voice Synthesizer</label>
                  <select
                    value={voiceName}
                    onChange={(e) => setVoiceName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-500 font-mono"
                  >
                    <option value="Kore">Kore (Warm Female)</option>
                    <option value="Zephyr">Zephyr (Calm Male)</option>
                    <option value="Puck">Puck (Cheerful)</option>
                    <option value="Fenrir">Fenrir (Deep Voice)</option>
                    <option value="Charon">Charon (Gentle Baritone)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Memory Photo URL</label>
                  <input
                    type="text"
                    value={photoUrl}
                    onChange={(e) => setPhotoUrl(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-500 font-mono text-[11px]"
                  />
                </div>
              </div>

              {/* Gemini AI Script Generator Button */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleGenerateScriptWithGemini}
                  disabled={isGeneratingScript || !beneficiaryName || !memories}
                  className="w-full bg-slate-800 hover:bg-slate-700 text-purple-300 border border-purple-500/40 p-2.5 rounded-xl font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  <span>{isGeneratingScript ? 'Gemini Writing Script...' : 'Generate AI Legacy Script with Gemini'}</span>
                </button>
              </div>

              {/* Display Generated Script Preview */}
              {generatedScriptPreview && (
                <div className="bg-slate-950 p-3 rounded-xl border border-purple-500/30 space-y-2 animate-fadeIn">
                  <div className="text-[11px] font-mono text-purple-400 font-bold uppercase">Generated Posthumous Message Script:</div>
                  <div className="text-slate-300 italic text-[11px] leading-relaxed max-h-32 overflow-y-auto p-2 bg-slate-900 rounded">
                    {generatedScriptPreview}
                  </div>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-purple-600 hover:bg-purple-500 text-white px-4 py-2 rounded-xl font-bold cursor-pointer shadow-md"
                >
                  Save Capsule to Vault
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
