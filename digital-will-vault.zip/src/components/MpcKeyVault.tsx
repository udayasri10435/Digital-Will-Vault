import React, { useState } from 'react';
import { KeyRound, ShieldCheck, Lock, Unlock, Users, Plus, Cpu, Sparkles, Copy, Check, Eye, EyeOff, AlertCircle, FileText, ChevronRight } from 'lucide-react';
import { DigitalAssetKey, MPCShard } from '../types';

interface MpcKeyVaultProps {
  assets: DigitalAssetKey[];
  isActivated: boolean;
  onAddAsset: (asset: DigitalAssetKey) => void;
  onAuditLog: (msg: string, type: 'SHARD_CREATED' | 'SECRET_UNLOCKED') => void;
}

export const MpcKeyVault: React.FC<MpcKeyVaultProps> = ({
  assets,
  isActivated,
  onAddAsset,
  onAuditLog,
}) => {
  const [selectedAssetId, setSelectedAssetId] = useState<string>(assets[0]?.id || '');
  const [selectedShards, setSelectedShards] = useState<number[]>([]);
  const [reconstructedSecret, setReconstructedSecret] = useState<string | null>(null);
  const [isReconstructing, setIsReconstructing] = useState<boolean>(false);
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [aiAuditResult, setAiAuditResult] = useState<any | null>(null);
  const [isAuditing, setIsAuditing] = useState<boolean>(false);

  // New asset form state
  const [newLabel, setNewLabel] = useState('');
  const [newCategory, setNewCategory] = useState<DigitalAssetKey['category']>('CRYPTO_SEED');
  const [newSecret, setNewSecret] = useState('');
  const [newBeneficiary, setNewBeneficiary] = useState('Elena Vance');
  const [newTotalShards, setNewTotalShards] = useState(3);
  const [newThreshold, setNewThreshold] = useState(2);

  const selectedAsset = assets.find((a) => a.id === selectedAssetId) || assets[0];

  const handleToggleShardSelect = (index: number) => {
    if (selectedShards.includes(index)) {
      setSelectedShards(selectedShards.filter((i) => i !== index));
    } else {
      setSelectedShards([...selectedShards, index]);
    }
  };

  const handleSimulateReconstruction = () => {
    if (!selectedAsset) return;
    setIsReconstructing(true);
    setReconstructedSecret(null);

    setTimeout(() => {
      setIsReconstructing(false);
      setReconstructedSecret(selectedAsset.secretContent);
      onAuditLog(
        `MPC Shards [${selectedShards.join(', ')}] assembled for "${selectedAsset.label}". Lagrange interpolation unlocked master secret.`,
        'SECRET_UNLOCKED'
      );
    }, 1200);
  };

  const handleRunAiAudit = async () => {
    if (!selectedAsset) return;
    setIsAuditing(true);
    setAiAuditResult(null);

    try {
      const res = await fetch('/api/gemini/mpc-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          totalShards: selectedAsset.totalShards,
          threshold: selectedAsset.threshold,
          assetType: selectedAsset.category,
          label: selectedAsset.label
        })
      });
      const data = await res.json();
      setAiAuditResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsAuditing(false);
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleCreateAssetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLabel || !newSecret) return;

    // Generate mock shards
    const generatedShards: MPCShard[] = [
      { shardIndex: 1, holderName: 'Dr. Aris Thorne (Trustee)', holderEmail: 'aris.thorne@legacytrust.io', shardHash: '0x' + Math.random().toString(16).substring(2, 18) + 'a1b2', isDelivered: false },
      { shardIndex: 2, holderName: newBeneficiary, holderEmail: 'beneficiary@legacy.org', shardHash: '0x' + Math.random().toString(16).substring(2, 18) + 'c3d4', isDelivered: false },
      { shardIndex: 3, holderName: 'Estate Secondary Trustee', holderEmail: 'trustee2@legacy.org', shardHash: '0x' + Math.random().toString(16).substring(2, 18) + 'e5f6', isDelivered: false }
    ].slice(0, newTotalShards);

    const created: DigitalAssetKey = {
      id: 'asset-' + Date.now(),
      label: newLabel,
      category: newCategory,
      secretContent: newSecret,
      totalShards: newTotalShards,
      threshold: newThreshold,
      beneficiaryName: newBeneficiary,
      shards: generatedShards,
      createdAt: new Date().toISOString()
    };

    onAddAsset(created);
    onAuditLog(`New Vault Key created: "${newLabel}" with ${newThreshold}-of-${newTotalShards} MPC sharding policy.`, 'SHARD_CREATED');

    setNewLabel('');
    setNewSecret('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold uppercase tracking-wider">
            <Cpu className="w-4 h-4" />
            <span>Multi-Party Computation (MPC) Key Vault</span>
          </div>
          <h2 className="text-xl font-bold text-white font-serif">Crypto Seeds & Secret Key Sharding</h2>
          <p className="text-xs text-slate-400 max-w-2xl">
            Sensitive seed phrases and master passwords are never stored in plain text. They are split into distributed key shards ($k$-of-$n$ threshold scheme). Reassembly requires active Dead Man's Switch execution or trustee quorum.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="bg-amber-500 hover:bg-amber-400 text-slate-950 px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-amber-950/40"
        >
          <Plus className="w-4 h-4" />
          <span>Vault New Secret Key</span>
        </button>
      </div>

      {/* Main Grid: Asset List Left + Interactive Shard Playground Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Asset Selector List (5 Cols) */}
        <div className="lg:col-span-5 space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1">
            Vaulted Assets ({assets.length})
          </h3>

          <div className="space-y-2.5">
            {assets.map((asset) => {
              const isSelected = selectedAsset?.id === asset.id;
              return (
                <div
                  key={asset.id}
                  onClick={() => {
                    setSelectedAssetId(asset.id);
                    setSelectedShards([]);
                    setReconstructedSecret(null);
                    setAiAuditResult(null);
                  }}
                  className={`border rounded-2xl p-4 transition-all cursor-pointer space-y-2.5 ${
                    isSelected
                      ? 'bg-slate-800/90 border-amber-500/50 shadow-xl shadow-amber-950/20 ring-1 ring-amber-500/30'
                      : 'bg-slate-900/70 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-1">
                      <span className="inline-block px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-slate-800 text-amber-400 border border-slate-700">
                        {asset.category.replace('_', ' ')}
                      </span>
                      <h4 className="text-sm font-bold text-white">{asset.label}</h4>
                    </div>

                    <div className="p-2 rounded-lg bg-slate-800 text-slate-300">
                      <Lock className="w-4 h-4 text-amber-400" />
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-400 border-t border-slate-800/80 pt-2 font-mono">
                    <span>Target: {asset.beneficiaryName}</span>
                    <span className="text-amber-400 font-semibold">{asset.threshold}-of-{asset.totalShards} Shards</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Shard Reconstruction & Audit Visualizer (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          {selectedAsset && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
              
              {/* Asset Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div>
                  <span className="text-xs font-mono text-amber-400 uppercase tracking-wider font-semibold">
                    Shamir's Secret Sharing Scheme ({selectedAsset.threshold}-of-{selectedAsset.totalShards})
                  </span>
                  <h3 className="text-lg font-bold text-white font-serif">{selectedAsset.label}</h3>
                </div>

                <button
                  onClick={handleRunAiAudit}
                  disabled={isAuditing}
                  className="bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>{isAuditing ? 'Analyzing Security...' : 'Gemini Cryptographic Audit'}</span>
                </button>
              </div>

              {/* AI Audit Result Box if Generated */}
              {aiAuditResult && (
                <div className="bg-slate-950/80 border border-amber-500/30 rounded-xl p-4 text-xs space-y-2 animate-fadeIn">
                  <div className="flex items-center gap-2 text-amber-400 font-bold font-serif text-sm">
                    <ShieldCheck className="w-4 h-4 text-amber-400" />
                    <span>{aiAuditResult.securityLevel || 'Cryptographic Audit'}</span>
                  </div>
                  <p className="text-slate-300 leading-relaxed">{aiAuditResult.summary}</p>
                  <div className="text-slate-400 font-mono text-[11px] bg-slate-900 p-2 rounded border border-slate-800">
                    <strong>Recovery Mechanism:</strong> {aiAuditResult.recoveryScenario}
                  </div>
                </div>
              )}

              {/* Shard Holders List */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Distributed Shard Holders ({selectedAsset.shards.length})
                  </h4>
                  <span className="text-xs font-mono text-amber-400">
                    Selected: {selectedShards.length} / {selectedAsset.threshold} required
                  </span>
                </div>

                <div className="grid grid-cols-1 gap-2.5">
                  {selectedAsset.shards.map((shard) => {
                    const isSelected = selectedShards.includes(shard.shardIndex);
                    return (
                      <div
                        key={shard.shardIndex}
                        onClick={() => handleToggleShardSelect(shard.shardIndex)}
                        className={`border rounded-xl p-3.5 flex items-center justify-between gap-3 transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-amber-500/10 border-amber-500/60 shadow-md'
                            : 'bg-slate-800/50 border-slate-700/60 hover:bg-slate-800'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-mono font-bold text-xs ${
                            isSelected ? 'bg-amber-500 text-slate-950' : 'bg-slate-700 text-slate-300'
                          }`}>
                            #{shard.shardIndex}
                          </div>
                          <div>
                            <div className="text-xs font-bold text-white">{shard.holderName}</div>
                            <div className="text-[11px] font-mono text-slate-400 truncate max-w-[220px] sm:max-w-xs">
                              Shard Hash: {shard.shardHash}
                            </div>
                          </div>
                        </div>

                        <div className={`px-2.5 py-1 rounded text-[10px] font-mono font-semibold ${
                          isSelected ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-400 border border-slate-700'
                        }`}>
                          {isSelected ? 'SHARD ATTACHED' : 'CLICK TO ATTACH'}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Secret Reassembly Box */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <div className="text-xs font-bold text-white">Encrypted Secret Content</div>
                    <div className="text-[11px] text-slate-400">
                      Requires at least {selectedAsset.threshold} shards to reconstruct plain text.
                    </div>
                  </div>

                  <button
                    onClick={handleSimulateReconstruction}
                    disabled={selectedShards.length < selectedAsset.threshold || isReconstructing}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                      selectedShards.length >= selectedAsset.threshold
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-950/50'
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                    }`}
                  >
                    <Unlock className="w-3.5 h-3.5" />
                    <span>
                      {isReconstructing
                        ? 'Interpolating Polynomial...'
                        : selectedShards.length >= selectedAsset.threshold
                        ? 'Reconstruct Secret Key'
                        : `Select ${selectedAsset.threshold - selectedShards.length} More Shards`}
                    </span>
                  </button>
                </div>

                {/* Display Area */}
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-3.5 font-mono text-xs relative overflow-hidden">
                  {reconstructedSecret ? (
                    <div className="space-y-2 animate-fadeIn">
                      <div className="flex items-center justify-between text-emerald-400 font-semibold">
                        <span className="flex items-center gap-1.5">
                          <Check className="w-4 h-4" /> Secret Key Reassembled Successfully
                        </span>
                        <button
                          onClick={() => handleCopy(reconstructedSecret, 'secret')}
                          className="text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
                        >
                          {copiedId === 'secret' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedId === 'secret' ? 'Copied' : 'Copy Key'}</span>
                        </button>
                      </div>
                      <div className="p-3 bg-slate-950 rounded border border-emerald-500/30 text-amber-300 font-mono select-all break-all">
                        {reconstructedSecret}
                      </div>
                    </div>
                  ) : (
                    <div className="text-slate-500 text-center py-4 flex flex-col items-center justify-center gap-1">
                      <Lock className="w-5 h-5 text-slate-600 mb-1" />
                      <span>Encrypted: •••••••••••••••••••••••••••••••••••••••••••••</span>
                      <span className="text-[10px] text-slate-600">Select {selectedAsset.threshold} key shards above to trigger Lagrange reconstruction</span>
                    </div>
                  )}
                </div>
              </div>

            </div>
          )}
        </div>

      </div>

      {/* Modal: Vault New Key */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-scaleUp">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white font-serif flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-amber-400" />
                Vault New Secret Key
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white text-lg font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateAssetSubmit} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Key Label / Description</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ethereum Staking Wallet Key"
                  value={newLabel}
                  onChange={(e) => setNewLabel(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Asset Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="CRYPTO_SEED">Crypto Seed Phrase</option>
                    <option value="CLOUD_PASSWORD">Cloud Password</option>
                    <option value="BANK_VAULT">Bank / Vault Code</option>
                    <option value="SECURE_NOTE">Encrypted Note</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Primary Beneficiary</label>
                  <input
                    type="text"
                    required
                    value={newBeneficiary}
                    onChange={(e) => setNewBeneficiary(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Secret Content (Encrypted at Rest)</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Paste private key, seed phrase, or master recovery code..."
                  value={newSecret}
                  onChange={(e) => setNewSecret(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-amber-300 font-mono focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div className="space-y-1">
                  <label className="text-slate-400 font-mono">Total Shards ($n$)</label>
                  <input
                    type="number"
                    min={2}
                    max={5}
                    value={newTotalShards}
                    onChange={(e) => setNewTotalShards(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-400 font-mono">Threshold ($k$)</label>
                  <input
                    type="number"
                    min={2}
                    max={newTotalShards}
                    value={newThreshold}
                    onChange={(e) => setNewThreshold(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white font-mono"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-amber-500 hover:bg-amber-400 text-slate-950 px-4 py-2 rounded-xl font-bold cursor-pointer shadow-md"
                >
                  Generate Shards & Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
