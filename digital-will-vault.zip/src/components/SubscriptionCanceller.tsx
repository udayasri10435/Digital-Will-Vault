import React, { useState } from 'react';
import { CreditCard, ShieldCheck, Tv, Music, Cloud, HardDrive, Layers, Plus, FileText, CheckCircle2, AlertTriangle, Sparkles, Copy, Check, DollarSign, Ban } from 'lucide-react';
import { SubscriptionItem } from '../types';

interface SubscriptionCancellerProps {
  subscriptions: SubscriptionItem[];
  isActivated: boolean;
  onAddSubscription: (sub: SubscriptionItem) => void;
  onUpdateStatus: (id: string, status: SubscriptionItem['status']) => void;
  onAuditLog: (msg: string, type: 'NOTICE_SENT' | 'CHECK_IN') => void;
}

export const SubscriptionCanceller: React.FC<SubscriptionCancellerProps> = ({
  subscriptions,
  isActivated,
  onAddSubscription,
  onUpdateStatus,
  onAuditLog,
}) => {
  const [selectedSubForNotice, setSelectedSubForNotice] = useState<SubscriptionItem | null>(null);
  const [noticeText, setNoticeText] = useState<string>('');
  const [isGeneratingNotice, setIsGeneratingNotice] = useState<boolean>(false);
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [copiedNotice, setCopiedNotice] = useState<boolean>(false);

  // New subscription form state
  const [serviceName, setServiceName] = useState('');
  const [category, setCategory] = useState<SubscriptionItem['category']>('ENTERTAINMENT');
  const [monthlyCost, setMonthlyCost] = useState(14.99);
  const [accountEmail, setAccountEmail] = useState('user@digitalwill.vault');
  const [accountNumber, setAccountNumber] = useState('');

  const totalMonthlyCost = subscriptions.reduce((acc, item) => acc + item.monthlyCost, 0);
  const totalAnnualCost = totalMonthlyCost * 12;

  const handleGenerateNotice = async (sub: SubscriptionItem) => {
    setSelectedSubForNotice(sub);
    setIsGeneratingNotice(true);
    setNoticeText('');

    try {
      const res = await fetch('/api/gemini/subscription-notice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          serviceName: sub.serviceName,
          accountEmail: sub.accountEmail,
          accountNumber: sub.accountNumber || 'ACC-99120',
          executorName: 'Dr. Aris Thorne (Estate Executor)'
        })
      });
      const data = await res.json();
      setNoticeText(data.noticeText || '');
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingNotice(false);
    }
  };

  const handleExecuteAllCancellations = () => {
    subscriptions.forEach((sub) => {
      onUpdateStatus(sub.id, 'AUTO_CANCELLED');
    });
    onAuditLog(
      `Posthumous Disconnect Protocol executed for ${subscriptions.length} active subscriptions. Prevented estimated $${totalAnnualCost.toFixed(2)} annual family billing charges.`,
      'NOTICE_SENT'
    );
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!serviceName) return;

    const newSub: SubscriptionItem = {
      id: 'sub-' + Date.now(),
      serviceName,
      category,
      monthlyCost: Number(monthlyCost),
      accountEmail,
      accountNumber: accountNumber || 'ACC-' + Math.floor(Math.random() * 89999 + 10000),
      status: 'ACTIVE_MONITORED',
      iconName: 'CreditCard'
    };

    onAddSubscription(newSub);
    onAuditLog(`New subscription added to auto-cancel monitor: ${serviceName} ($${monthlyCost}/mo)`, 'CHECK_IN');

    setServiceName('');
    setAccountNumber('');
    setShowAddModal(false);
  };

  const handleCopyNotice = () => {
    navigator.clipboard.writeText(noticeText);
    setCopiedNotice(true);
    setTimeout(() => setCopiedNotice(null), 2000);
  };

  const getServiceIcon = (name: string) => {
    const lower = name.toLowerCase();
    if (lower.includes('music') || lower.includes('spotify')) return Music;
    if (lower.includes('tv') || lower.includes('netflix')) return Tv;
    if (lower.includes('aws') || lower.includes('cloud')) return Cloud;
    if (lower.includes('google') || lower.includes('drive')) return HardDrive;
    if (lower.includes('adobe')) return Layers;
    return CreditCard;
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold uppercase tracking-wider">
            <CreditCard className="w-4 h-4" />
            <span>Digital Footprint & Recurring Billing Manager</span>
          </div>
          <h2 className="text-xl font-bold text-white font-serif">Auto-Subscription Posthumous Canceller</h2>
          <p className="text-xs text-slate-400 max-w-2xl">
            Upon activation, Digital Will Vault dispatches certified cancellation requests and webhooks to streaming services, software suites, and cloud infrastructure so your family isn't billed for years after death.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setShowAddModal(true)}
            className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-emerald-950/40"
          >
            <Plus className="w-4 h-4" />
            <span>Add Subscription</span>
          </button>

          {isActivated && (
            <button
              onClick={handleExecuteAllCancellations}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-amber-950/40"
            >
              <Ban className="w-4 h-4" />
              <span>Cancel All Now</span>
            </button>
          )}
        </div>
      </div>

      {/* Burn Rate Metrics Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-1">
          <div className="text-xs text-slate-400">Total Monthly Cost</div>
          <div className="text-2xl font-bold text-white font-mono">${totalMonthlyCost.toFixed(2)} / mo</div>
          <p className="text-[11px] text-slate-500">Across {subscriptions.length} active services</p>
        </div>

        <div className="bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-5 shadow-lg space-y-1 bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/20">
          <div className="text-xs text-emerald-400 font-semibold">Protected Annual Family Savings</div>
          <div className="text-2xl font-bold text-emerald-300 font-mono">${totalAnnualCost.toFixed(2)} / yr</div>
          <p className="text-[11px] text-emerald-400/80">Saved upon Dead Man's Switch execution</p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-1">
          <div className="text-xs text-slate-400">Protocol Status</div>
          <div className={`text-base font-bold font-mono ${isActivated ? 'text-amber-400' : 'text-emerald-400'}`}>
            {isActivated ? 'DISCONNECT QUEUED' : 'MONITORING ACTIVE'}
          </div>
          <p className="text-[11px] text-slate-500">Auto-cancellation triggers ready</p>
        </div>
      </div>

      {/* Subscriptions Cards List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Tracked Subscriptions ({subscriptions.length})
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {subscriptions.map((sub) => {
            const Icon = getServiceIcon(sub.serviceName);
            const isCancelled = sub.status === 'AUTO_CANCELLED';

            return (
              <div
                key={sub.id}
                className={`border rounded-2xl p-4 transition-all flex flex-col justify-between space-y-3 ${
                  isCancelled
                    ? 'bg-slate-950/80 border-emerald-500/40 opacity-90'
                    : 'bg-slate-800/40 border-slate-700/60 hover:border-slate-600'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-xl ${isCancelled ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-amber-400'}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">{sub.serviceName}</h4>
                      <p className="text-xs text-slate-400 font-mono">{sub.accountEmail}</p>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-sm font-bold text-amber-300 font-mono">${sub.monthlyCost.toFixed(2)}/mo</div>
                    <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-mono font-bold mt-1 ${
                      isCancelled
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-slate-800 text-slate-300 border border-slate-700'
                    }`}>
                      {isCancelled ? 'TERMINATED' : 'ACTIVE'}
                    </span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-mono text-[11px]">Ref: {sub.accountNumber || 'N/A'}</span>

                  <button
                    onClick={() => handleGenerateNotice(sub)}
                    className="bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/30 px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 cursor-pointer text-xs"
                  >
                    <FileText className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Generate Cancellation Letter</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Modal / Panel: Generated Cancellation Notice */}
      {selectedSubForNotice && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl p-6 max-w-lg w-full shadow-2xl space-y-4 animate-scaleUp">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white font-serif flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-400" />
                Cancellation Notice for {selectedSubForNotice.serviceName}
              </h3>
              <button
                onClick={() => setSelectedSubForNotice(null)}
                className="text-slate-400 hover:text-white text-lg font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            {isGeneratingNotice ? (
              <div className="py-12 text-center text-slate-400 space-y-3 font-mono text-xs">
                <Sparkles className="w-6 h-6 text-emerald-400 animate-spin mx-auto" />
                <div>Gemini AI Drafting Legal Posthumous Termination Notice...</div>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-slate-300 font-mono text-xs whitespace-pre-wrap leading-relaxed max-h-64 overflow-y-auto">
                  {noticeText}
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                  <button
                    onClick={handleCopyNotice}
                    className="bg-slate-800 hover:bg-slate-700 text-white px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 cursor-pointer"
                  >
                    {copiedNotice ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-slate-400" />}
                    <span>{copiedNotice ? 'Copied' : 'Copy Notice Text'}</span>
                  </button>

                  <button
                    onClick={() => {
                      onUpdateStatus(selectedSubForNotice.id, 'AUTO_CANCELLED');
                      onAuditLog(`Posthumous Cancellation Notice dispatched for ${selectedSubForNotice.serviceName}.`, 'NOTICE_SENT');
                      setSelectedSubForNotice(null);
                    }}
                    className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-bold cursor-pointer shadow-md"
                  >
                    Simulate Auto-Dispatch
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal: Add Subscription */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-scaleUp">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white font-serif flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-emerald-400" />
                Add Monitored Subscription
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white text-lg font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Service Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Disney+ Premium, Gym Membership, AWS"
                  value={serviceName}
                  onChange={(e) => setServiceName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Monthly Cost ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={monthlyCost}
                    onChange={(e) => setMonthlyCost(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="ENTERTAINMENT">Entertainment</option>
                    <option value="CLOUD_STORAGE">Cloud Storage</option>
                    <option value="SOFTWARE">Software</option>
                    <option value="FITNESS">Fitness / Gym</option>
                    <option value="FINANCE">Finance / Utility</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Account Email / Username</label>
                <input
                  type="email"
                  required
                  value={accountEmail}
                  onChange={(e) => setAccountEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Account ID / Reference Number (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. SUB-99201"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-xl font-bold cursor-pointer shadow-md"
                >
                  Add Subscription
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
