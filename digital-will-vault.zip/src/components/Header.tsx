import React, { useState, useEffect } from 'react';
import { ShieldCheck, Clock, RefreshCw, Play, AlertTriangle, KeyRound, Sparkles, CreditCard, Heart, Users, FileText } from 'lucide-react';
import { DMSConfig } from '../types';

interface HeaderProps {
  dmsConfig: DMSConfig;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onCheckIn: () => void;
  onToggleSimulation: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  dmsConfig,
  activeTab,
  setActiveTab,
  onCheckIn,
  onToggleSimulation,
}) => {
  const [timeLeft, setTimeLeft] = useState<{ days: number; hours: number; minutes: number; seconds: number }>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    const calculateTime = () => {
      if (dmsConfig.status === 'ACTIVATED' || dmsConfig.isSimulationActive) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }
      const deadline = new Date(dmsConfig.nextCheckInDeadline).getTime();
      const now = new Date().getTime();
      const diff = Math.max(0, deadline - now);

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      setTimeLeft({ days, hours, minutes, seconds });
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [dmsConfig]);

  const navItems = [
    { id: 'dashboard', label: 'Vault Overview', icon: ShieldCheck },
    { id: 'mpc-vault', label: 'MPC Key Vault', icon: KeyRound },
    { id: 'legacy-capsules', label: 'AI Legacy Capsules', icon: Sparkles },
    { id: 'subscriptions', label: 'Auto-Subscriptions', icon: CreditCard },
    { id: 'funeral-wishes', label: 'Memorial Wishes', icon: Heart },
    { id: 'beneficiaries', label: 'Beneficiaries & Trustees', icon: Users },
  ];

  const isActivated = dmsConfig.status === 'ACTIVATED' || dmsConfig.isSimulationActive;

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-40 shadow-xl">
      {/* Top Banner for Simulation or Activation */}
      {isActivated && (
        <div className="bg-amber-600/90 text-amber-100 px-4 py-2 text-xs md:text-sm font-medium flex items-center justify-between animate-pulse">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-200" />
            <span>
              <strong>[POSTHUMOUS PROTOCOL ACTIVATED]</strong> Vault execution in progress. Shards distributed, subscriptions queueing cancellation, AI legacy capsules unlocked.
            </span>
          </div>
          <button
            onClick={onToggleSimulation}
            className="bg-amber-950 hover:bg-amber-900 text-amber-200 px-3 py-1 rounded border border-amber-500/40 text-xs font-semibold cursor-pointer transition-colors"
          >
            Reset Simulation
          </button>
        </div>
      )}

      {/* Primary Header Row */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          
          {/* Brand & Status Pill */}
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-br from-amber-500 to-amber-700 rounded-xl shadow-lg shadow-amber-900/30 text-slate-950 font-bold">
              <ShieldCheck className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-white font-serif">Digital Will Vault</h1>
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-800 text-amber-400 border border-amber-500/20">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  MPC 256-Bit Encrypted
                </span>
              </div>
              <p className="text-xs text-slate-400">Autonomous Legacy Protection & Dead Man's Switch Protocol</p>
            </div>
          </div>

          {/* Countdown Timer & Ping Action */}
          <div className="flex flex-wrap items-center gap-3 bg-slate-800/80 border border-slate-700/60 p-2.5 rounded-2xl">
            <div className="flex items-center gap-2 px-2">
              <Clock className="w-4 h-4 text-amber-400" />
              <div className="text-xs">
                <div className="text-slate-400 uppercase tracking-wider text-[10px]">DMS Countdown</div>
                <div className="font-mono text-sm font-semibold text-slate-100">
                  {isActivated ? (
                    <span className="text-amber-400 font-bold">ACTIVATED</span>
                  ) : (
                    `${timeLeft.days}d ${timeLeft.hours}h ${timeLeft.minutes}m ${timeLeft.seconds}s`
                  )}
                </div>
              </div>
            </div>

            <div className="h-8 w-px bg-slate-700 hidden sm:block" />

            {/* Check-In Ping Button */}
            <button
              onClick={onCheckIn}
              disabled={isActivated}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold shadow-md transition-all cursor-pointer ${
                isActivated
                  ? 'bg-slate-700 text-slate-500 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/40 hover:scale-[1.02]'
              }`}
              title="Ping server to prove you are alive and reset the 6-month Dead Man's Switch countdown"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Ping "I'm Alive"</span>
            </button>

            {/* Test Execution Simulation Button */}
            <button
              onClick={onToggleSimulation}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                isActivated
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 hover:bg-amber-500/30'
                  : 'bg-slate-700/70 hover:bg-slate-700 text-amber-300 border-amber-500/30 hover:border-amber-400/60'
              }`}
              title="Simulate Dead Man's Switch expiration to preview posthumous vault execution"
            >
              <Play className="w-3.5 h-3.5 text-amber-400 fill-amber-400/30" />
              <span>{isActivated ? 'Exit Test Mode' : 'Test Will Execution'}</span>
            </button>
          </div>

        </div>

        {/* Tab Navigation */}
        <nav className="flex items-center gap-1 mt-5 overflow-x-auto pb-1 scrollbar-none border-t border-slate-800/80 pt-3">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
