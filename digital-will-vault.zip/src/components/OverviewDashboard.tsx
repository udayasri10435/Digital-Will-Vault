import React from 'react';
import { ShieldCheck, Clock, KeyRound, Sparkles, CreditCard, Heart, Users, RefreshCw, Play, AlertCircle, CheckCircle2, Lock, ArrowRight, ShieldAlert, FileText } from 'lucide-react';
import { DMSConfig, DigitalAssetKey, LegacyCapsule, SubscriptionItem, FuneralWishList, AuditLog } from '../types';

interface OverviewProps {
  dmsConfig: DMSConfig;
  assets: DigitalAssetKey[];
  capsules: LegacyCapsule[];
  subscriptions: SubscriptionItem[];
  funeralWishes: FuneralWishList;
  logs: AuditLog[];
  onCheckIn: () => void;
  onToggleSimulation: () => void;
  setActiveTab: (tab: string) => void;
}

export const OverviewDashboard: React.FC<OverviewProps> = ({
  dmsConfig,
  assets,
  capsules,
  subscriptions,
  funeralWishes,
  logs,
  onCheckIn,
  onToggleSimulation,
  setActiveTab,
}) => {
  const isActivated = dmsConfig.status === 'ACTIVATED' || dmsConfig.isSimulationActive;

  // Calculate annual subscription savings
  const totalMonthlyCost = subscriptions.reduce((acc, curr) => acc + curr.monthlyCost, 0);
  const totalAnnualCost = totalMonthlyCost * 12;

  // Calculate progress % toward deadline
  const lastTime = new Date(dmsConfig.lastCheckIn).getTime();
  const nextTime = new Date(dmsConfig.nextCheckInDeadline).getTime();
  const totalWindow = Math.max(1, nextTime - lastTime);
  const elapsed = Math.max(0, Date.now() - lastTime);
  const percentUsed = Math.min(100, Math.max(0, (elapsed / totalWindow) * 100));
  const percentRemaining = (100 - percentUsed).toFixed(1);

  return (
    <div className="space-y-6">
      
      {/* Simulation Banner if Active */}
      {isActivated && (
        <div className="bg-gradient-to-r from-amber-900/80 via-amber-950 to-slate-900 border border-amber-500/40 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
          <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold">
                <ShieldAlert className="w-4 h-4 text-amber-400" />
                <span>Simulated Execution Mode Active</span>
              </div>
              <h2 className="text-xl font-bold text-white font-serif">Dead Man's Switch Triggered</h2>
              <p className="text-sm text-slate-300 max-w-2xl">
                The 6-month check-in timer has reached zero in test mode. See how Multi-Party Computation shards reassemble, subscription cancellation notices generate, and AI legacy video capsules unlock for loved ones.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={() => setActiveTab('legacy-capsules')}
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shadow-lg shadow-amber-900/40 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>Watch AI Video Capsules</span>
              </button>
              <button
                onClick={() => setActiveTab('mpc-vault')}
                className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-4 py-2.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 cursor-pointer"
              >
                <KeyRound className="w-4 h-4 text-amber-400" />
                <span>View Unlocked MPC Shards</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top Main Dead Man's Switch Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          
          {/* DMS Main Info */}
          <div className="space-y-3 flex-1">
            <div className="flex items-center gap-3">
              <div className={`p-2.5 rounded-xl border ${isActivated ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'}`}>
                <Clock className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-white font-serif">Dead Man's Switch Engine</h2>
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${isActivated ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'}`}>
                    {isActivated ? 'SIMULATED ACTIVATION' : 'MONITORING HEALTHY'}
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  Configured Check-In Interval: <strong className="text-slate-200">{dmsConfig.checkInFrequencyMonths} Months</strong> • Grace Period: <strong className="text-slate-200">{dmsConfig.gracePeriodDays} Days</strong>
                </p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="space-y-1.5 pt-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">Timer Window Elapsed: {percentUsed.toFixed(1)}%</span>
                <span className="text-amber-400 font-semibold">{percentRemaining}% Time Remaining</span>
              </div>
              <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden p-0.5 border border-slate-700/60">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${isActivated ? 'bg-amber-500' : 'bg-gradient-to-r from-emerald-500 to-amber-400'}`}
                  style={{ width: isActivated ? '100%' : `${percentUsed}%` }}
                />
              </div>
            </div>
          </div>

          {/* Quick Check-In CTA Box */}
          <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 min-w-[280px]">
            <div className="text-center sm:text-left">
              <div className="text-xs text-slate-400">Last Verified Check-In</div>
              <div className="text-sm font-semibold text-slate-100 font-mono">
                {new Date(dmsConfig.lastCheckIn).toLocaleDateString(undefined, { dateStyle: 'medium' })}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Next Deadline: {new Date(dmsConfig.nextCheckInDeadline).toLocaleDateString(undefined, { dateStyle: 'medium' })}
              </div>
            </div>

            <button
              onClick={onCheckIn}
              disabled={isActivated}
              className={`w-full sm:w-auto px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg ${
                isActivated
                  ? 'bg-slate-700 text-slate-500 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950/50 hover:scale-[1.02]'
              }`}
            >
              <RefreshCw className="w-4 h-4" />
              <span>Ping "I'm Alive"</span>
            </button>
          </div>

        </div>

        {/* Verifiers & Heartbeats inline */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2 text-slate-300">
            <Users className="w-4 h-4 text-amber-400" />
            <span>Designated Estate Verifiers ({dmsConfig.verifiers.length}):</span>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {dmsConfig.verifiers.map((ver) => (
              <div key={ver.id} className="flex items-center gap-2 bg-slate-800/60 border border-slate-700/60 px-3 py-1.5 rounded-lg text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span className="font-medium text-slate-200">{ver.name}</span>
                <span className="text-[10px] text-slate-400">({ver.relationship})</span>
              </div>
            ))}
            <button
              onClick={() => setActiveTab('beneficiaries')}
              className="text-amber-400 hover:text-amber-300 text-xs font-semibold flex items-center gap-1 cursor-pointer"
            >
              Manage Verifiers <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* 4 Feature Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: MPC Key Vault */}
        <div
          onClick={() => setActiveTab('mpc-vault')}
          className="bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 rounded-2xl p-5 shadow-lg transition-all hover:translate-y-[-2px] cursor-pointer group space-y-3"
        >
          <div className="flex items-center justify-between">
            <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl group-hover:bg-amber-500/20 transition-colors">
              <KeyRound className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono bg-slate-800 text-amber-300 px-2.5 py-1 rounded-full border border-slate-700">
              {assets.length} Keys Vaulted
            </span>
          </div>
          <div>
            <h3 className="text-base font-bold text-white group-hover:text-amber-300 transition-colors">MPC Key Sharding</h3>
            <p className="text-xs text-slate-400 mt-1">
              Crypto seeds & passwords mathematically split into multi-party threshold shards.
            </p>
          </div>
          <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>Threshold: 2-of-3 Keys</span>
            <span className="text-amber-400 group-hover:translate-x-1 transition-transform">Explore →</span>
          </div>
        </div>

        {/* Card 2: AI Legacy Capsules */}
        <div
          onClick={() => setActiveTab('legacy-capsules')}
          className="bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 rounded-2xl p-5 shadow-lg transition-all hover:translate-y-[-2px] cursor-pointer group space-y-3"
        >
          <div className="flex items-center justify-between">
            <div className="p-2.5 bg-purple-500/10 text-purple-400 rounded-xl group-hover:bg-purple-500/20 transition-colors">
              <Sparkles className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono bg-slate-800 text-purple-300 px-2.5 py-1 rounded-full border border-slate-700">
              {capsules.length} Video Capsules
            </span>
          </div>
          <div>
            <h3 className="text-base font-bold text-white group-hover:text-purple-300 transition-colors">AI Legacy Messages</h3>
            <p className="text-xs text-slate-400 mt-1">
              Personalized video messages and spoken voice narration generated for family.
            </p>
          </div>
          <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>Gemini AI Voice Synthesized</span>
            <span className="text-purple-400 group-hover:translate-x-1 transition-transform">Preview →</span>
          </div>
        </div>

        {/* Card 3: Auto Subscription Canceller */}
        <div
          onClick={() => setActiveTab('subscriptions')}
          className="bg-slate-900/90 border border-slate-800 hover:border-emerald-500/40 rounded-2xl p-5 shadow-lg transition-all hover:translate-y-[-2px] cursor-pointer group space-y-3"
        >
          <div className="flex items-center justify-between">
            <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl group-hover:bg-emerald-500/20 transition-colors">
              <CreditCard className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono bg-slate-800 text-emerald-300 px-2.5 py-1 rounded-full border border-slate-700">
              ${totalAnnualCost.toFixed(0)}/yr Saved
            </span>
          </div>
          <div>
            <h3 className="text-base font-bold text-white group-hover:text-emerald-300 transition-colors">Auto-Cancel Subs</h3>
            <p className="text-xs text-slate-400 mt-1">
              Spotify, Netflix, AWS, Adobe auto-cancellation upon death to prevent ongoing billing.
            </p>
          </div>
          <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>{subscriptions.length} Subscriptions Tracked</span>
            <span className="text-emerald-400 group-hover:translate-x-1 transition-transform">Manage →</span>
          </div>
        </div>

        {/* Card 4: Funeral & Memorial Wishes */}
        <div
          onClick={() => setActiveTab('funeral-wishes')}
          className="bg-slate-900/90 border border-slate-800 hover:border-rose-500/40 rounded-2xl p-5 shadow-lg transition-all hover:translate-y-[-2px] cursor-pointer group space-y-3"
        >
          <div className="flex items-center justify-between">
            <div className="p-2.5 bg-rose-500/10 text-rose-400 rounded-xl group-hover:bg-rose-500/20 transition-colors">
              <Heart className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono bg-slate-800 text-rose-300 px-2.5 py-1 rounded-full border border-slate-700">
              {funeralWishes.dispositionType.replace('_', ' ')}
            </span>
          </div>
          <div>
            <h3 className="text-base font-bold text-white group-hover:text-rose-300 transition-colors">Memorial Wish List</h3>
            <p className="text-xs text-slate-400 mt-1">
              Funeral preferences, acoustic playlist, attire code, and charity choices.
            </p>
          </div>
          <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>{funeralWishes.musicPlaylist.length} Songs Chosen</span>
            <span className="text-rose-400 group-hover:translate-x-1 transition-transform">View →</span>
          </div>
        </div>

      </div>

      {/* Security & Audit Logs Section */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-bold text-white font-serif">Vault Protocol Audit Ledger</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">Immutable Log Entries: {logs.length}</span>
        </div>

        <div className="space-y-2.5">
          {logs.map((log) => (
            <div
              key={log.id}
              className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
            >
              <div className="flex items-start gap-3">
                <span className={`p-1.5 rounded-lg mt-0.5 ${
                  log.severity === 'ALERT'
                    ? 'bg-amber-500/20 text-amber-400'
                    : log.severity === 'WARNING'
                    ? 'bg-amber-500/10 text-amber-300'
                    : 'bg-emerald-500/10 text-emerald-400'
                }`}>
                  <ShieldCheck className="w-4 h-4" />
                </span>
                <div>
                  <p className="text-slate-200 font-medium">{log.message}</p>
                  <span className="text-[11px] text-slate-400 font-mono">{log.timestamp}</span>
                </div>
              </div>

              <span className={`self-start sm:self-center px-2 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider font-semibold ${
                log.severity === 'ALERT'
                  ? 'bg-amber-950 text-amber-400 border border-amber-500/30'
                  : 'bg-slate-800 text-slate-300 border border-slate-700'
              }`}>
                {log.type}
              </span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
