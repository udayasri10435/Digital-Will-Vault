import React, { useState } from 'react';
import { Heart, Music, TreePine, Sparkles, Plus, Trash2, MapPin, Shirt, Gift, FileText, Check } from 'lucide-react';
import { FuneralWishList } from '../types';

interface FuneralWishesProps {
  wishes: FuneralWishList;
  onUpdateWishes: (wishes: FuneralWishList) => void;
  onAuditLog: (msg: string, type: 'CHECK_IN') => void;
}

export const FuneralWishes: React.FC<FuneralWishesProps> = ({
  wishes,
  onUpdateWishes,
  onAuditLog,
}) => {
  const [newSong, setNewSong] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<FuneralWishList>({ ...wishes });
  const [aiMemorialPlan, setAiMemorialPlan] = useState<string | null>(null);
  const [isGeneratingPlan, setIsGeneratingPlan] = useState(false);

  const handleAddSong = () => {
    if (!newSong.trim()) return;
    const updated = { ...formData, musicPlaylist: [...formData.musicPlaylist, newSong.trim()] };
    setFormData(updated);
    setNewSong('');
  };

  const handleRemoveSong = (index: number) => {
    const updated = { ...formData, musicPlaylist: formData.musicPlaylist.filter((_, i) => i !== index) };
    setFormData(updated);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateWishes(formData);
    onAuditLog('Funeral and memorial wish list preferences updated.', 'CHECK_IN');
    setIsEditing(false);
  };

  const handleGenerateMemorialPlan = async () => {
    setIsGeneratingPlan(true);
    setAiMemorialPlan(null);

    try {
      const res = await fetch('/api/gemini/legacy-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          beneficiaryName: 'Family & Friends Gathering',
          relationship: 'Celebration of Life',
          memories: formData.specialRequests || 'A life lived with joy and love',
          tone: 'Uplifting, Celebration of Life, Warm',
          wishList: formData.eulogyInstructions
        })
      });
      const data = await res.json();
      setAiMemorialPlan(data.script || '');
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingPlan(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-rose-400 text-xs font-semibold uppercase tracking-wider">
            <Heart className="w-4 h-4" />
            <span>Posthumous Funeral & Celebration Wishes</span>
          </div>
          <h2 className="text-xl font-bold text-white font-serif">Memorial & Celebration Preferences</h2>
          <p className="text-xs text-slate-400 max-w-2xl">
            Ensure your family never has to guess your final wishes. Detail your preferred burial type, acoustic playlist, dress code, charity donations, and eulogy instructions.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={handleGenerateMemorialPlan}
            disabled={isGeneratingPlan}
            className="bg-slate-800 hover:bg-slate-700 text-rose-300 border border-rose-500/30 px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-lg"
          >
            <Sparkles className="w-4 h-4 text-rose-400" />
            <span>{isGeneratingPlan ? 'Creating Plan...' : 'Gemini Memorial Plan'}</span>
          </button>

          <button
            onClick={() => setIsEditing(!isEditing)}
            className="bg-rose-600 hover:bg-rose-500 text-white px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-rose-950/40"
          >
            <span>{isEditing ? 'Cancel Edit' : 'Edit Preferences'}</span>
          </button>
        </div>
      </div>

      {/* AI Generated Memorial Framework if present */}
      {aiMemorialPlan && (
        <div className="bg-slate-900 border border-rose-500/40 rounded-2xl p-6 shadow-xl space-y-3 animate-fadeIn">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2 text-rose-300 font-bold font-serif text-sm">
              <Sparkles className="w-4 h-4 text-rose-400" />
              <span>Gemini AI Memorial Celebration Outline</span>
            </div>
            <button
              onClick={() => setAiMemorialPlan(null)}
              className="text-slate-400 hover:text-white text-xs font-mono cursor-pointer"
            >
              Close
            </button>
          </div>
          <div className="text-slate-300 text-xs font-serif leading-relaxed italic bg-slate-950 p-4 rounded-xl border border-slate-800 whitespace-pre-wrap">
            {aiMemorialPlan}
          </div>
        </div>
      )}

      {/* Main Form or Display Card */}
      {isEditing ? (
        <form onSubmit={handleSave} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-slate-300 font-semibold">Memorial Type</label>
              <select
                value={formData.dispositionType}
                onChange={(e) => setFormData({ ...formData, dispositionType: e.target.value as any })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-rose-500"
              >
                <option value="MEMORIAL_TREE">Memorial Tree (Redwood / Oak Sapling)</option>
                <option value="GREEN_BURIAL">Eco-Friendly Green Burial</option>
                <option value="CREMATION">Cremation & Ash Scattering</option>
                <option value="TRADITIONAL_BURIAL">Traditional Funeral Burial</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-semibold">Preferred Venue Location</label>
              <input
                type="text"
                value={formData.venuePreference}
                onChange={(e) => setFormData({ ...formData, venuePreference: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-slate-300 font-semibold">Attire & Dress Code Request</label>
              <input
                type="text"
                value={formData.attireCode}
                onChange={(e) => setFormData({ ...formData, attireCode: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-rose-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-semibold">Charity of Choice (In Lieu of Flowers)</label>
              <input
                type="text"
                value={formData.charityOfChoice}
                onChange={(e) => setFormData({ ...formData, charityOfChoice: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>

          {/* Music Playlist Section */}
          <div className="space-y-2 bg-slate-950 p-4 rounded-xl border border-slate-800">
            <label className="text-slate-300 font-semibold flex items-center gap-2">
              <Music className="w-4 h-4 text-rose-400" />
              <span>Memorial Music Playlist</span>
            </label>

            <div className="flex gap-2">
              <input
                type="text"
                placeholder="e.g. Clair de Lune - Debussy"
                value={newSong}
                onChange={(e) => setNewSong(e.target.value)}
                className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-white focus:outline-none focus:border-rose-500"
              />
              <button
                type="button"
                onClick={handleAddSong}
                className="bg-rose-600 hover:bg-rose-500 text-white px-3 py-1.5 rounded-xl font-bold cursor-pointer"
              >
                Add Song
              </button>
            </div>

            <div className="space-y-1 pt-2">
              {formData.musicPlaylist.map((song, i) => (
                <div key={i} className="flex items-center justify-between bg-slate-900 p-2 rounded border border-slate-800 text-slate-200 font-mono text-[11px]">
                  <span>🎵 {song}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveSong(i)}
                    className="text-slate-500 hover:text-rose-400 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-semibold">Eulogy & Speech Instructions</label>
            <textarea
              rows={3}
              value={formData.eulogyInstructions}
              onChange={(e) => setFormData({ ...formData, eulogyInstructions: e.target.value })}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-200 focus:outline-none focus:border-rose-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-semibold">Special Legacy Requests</label>
            <textarea
              rows={2}
              value={formData.specialRequests}
              onChange={(e) => setFormData({ ...formData, specialRequests: e.target.value })}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-200 focus:outline-none focus:border-rose-500"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="px-4 py-2 rounded-xl text-slate-400 hover:text-white cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-rose-600 hover:bg-rose-500 text-white px-5 py-2 rounded-xl font-bold cursor-pointer shadow-md"
            >
              Save Memorial Preferences
            </button>
          </div>
        </form>
      ) : (
        /* Readonly Display Card Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Left Column */}
          <div className="space-y-6">
            
            {/* Disposition & Venue */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-rose-500/10 text-rose-400 rounded-xl">
                  <TreePine className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-xs text-slate-400 font-mono">Memorial Type</div>
                  <h3 className="text-base font-bold text-white font-serif">
                    {wishes.dispositionType.replace('_', ' ')}
                  </h3>
                </div>
              </div>

              <div className="space-y-3 pt-2 text-xs text-slate-300">
                <div className="flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block font-semibold">Preferred Venue:</strong>
                    <span className="text-slate-400">{wishes.venuePreference}</span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <Shirt className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block font-semibold">Requested Attire & Atmosphere:</strong>
                    <span className="text-slate-400">{wishes.attireCode}</span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <Gift className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block font-semibold">In Lieu of Flowers:</strong>
                    <span className="text-slate-400">{wishes.charityOfChoice}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Special Legacy Requests */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-2 text-xs">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                <FileText className="w-4 h-4 text-rose-400" />
                <span>Special Legacy Request</span>
              </h4>
              <p className="text-slate-300 italic leading-relaxed bg-slate-950 p-4 rounded-xl border border-slate-800">
                "{wishes.specialRequests}"
              </p>
            </div>

          </div>

          {/* Right Column */}
          <div className="space-y-6">
            
            {/* Music Playlist */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-3">
              <div className="flex items-center gap-2">
                <Music className="w-5 h-5 text-rose-400" />
                <h3 className="text-base font-bold text-white font-serif">Acoustic Memorial Playlist</h3>
              </div>

              <div className="space-y-2">
                {wishes.musicPlaylist.map((song, i) => (
                  <div key={i} className="bg-slate-800/60 border border-slate-700/60 p-3 rounded-xl flex items-center justify-between text-xs text-slate-200">
                    <span className="font-medium font-mono">{song}</span>
                    <span className="text-[10px] text-rose-400 font-mono">Track #{i + 1}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Eulogy Notes */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-2 text-xs">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Eulogy & Celebration Guidelines
              </h4>
              <p className="text-slate-300 leading-relaxed bg-slate-950 p-4 rounded-xl border border-slate-800">
                {wishes.eulogyInstructions}
              </p>
            </div>

          </div>

        </div>
      )}

    </div>
  );
};
