import React, { useState } from 'react';
import { Users, ShieldCheck, PieChart, Plus, Mail, Phone, CheckCircle2, AlertCircle, KeyRound, UserCheck } from 'lucide-react';
import { BeneficiaryAllocation, Verifier } from '../types';

interface BeneficiariesMatrixProps {
  beneficiaries: BeneficiaryAllocation[];
  verifiers: Verifier[];
  onAddBeneficiary: (ben: BeneficiaryAllocation) => void;
  onAuditLog: (msg: string, type: 'CHECK_IN') => void;
}

export const BeneficiariesMatrix: React.FC<BeneficiariesMatrixProps> = ({
  beneficiaries,
  verifiers,
  onAddBeneficiary,
  onAuditLog,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [relationship, setRelationship] = useState('Daughter');
  const [percentage, setPercentage] = useState(25);
  const [assignedAssets, setAssignedAssets] = useState('Digital Photo Archive, Secondary Vault');

  const totalAllocated = beneficiaries.reduce((acc, b) => acc + b.assetSharePercentage, 0);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) return;

    const newBen: BeneficiaryAllocation = {
      id: 'ben-' + Date.now(),
      name,
      email,
      relationship,
      assetSharePercentage: Number(percentage),
      assignedAssetLabels: assignedAssets.split(',').map((s) => s.trim()),
      shardCountAssigned: 1
    };

    onAddBeneficiary(newBen);
    onAuditLog(`New beneficiary added: ${name} (${relationship}) with ${percentage}% digital asset allocation share.`, 'CHECK_IN');

    setName('');
    setEmail('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold uppercase tracking-wider">
            <Users className="w-4 h-4" />
            <span>Estate Trustees & Beneficiary Allocation Matrix</span>
          </div>
          <h2 className="text-xl font-bold text-white font-serif">Beneficiaries & Trustee Network</h2>
          <p className="text-xs text-slate-400 max-w-2xl">
            Assign digital estate percentages, designate Dead Man's Switch heartbeat verifiers, and manage trustee key shard assignments.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="bg-amber-500 hover:bg-amber-400 text-slate-950 px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-amber-950/40"
        >
          <Plus className="w-4 h-4" />
          <span>Add Beneficiary</span>
        </button>
      </div>

      {/* Asset Distribution Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-3">
        <div className="flex items-center justify-between text-xs font-mono">
          <span className="text-slate-400">Digital Asset Share Allocation Ledger</span>
          <span className="text-amber-400 font-bold">{totalAllocated}% Total Assigned</span>
        </div>

        {/* Visual Bar */}
        <div className="w-full h-4 bg-slate-950 rounded-full overflow-hidden p-1 flex border border-slate-800">
          {beneficiaries.map((b, i) => (
            <div
              key={b.id}
              className={`h-full transition-all ${
                i === 0 ? 'bg-amber-500' : i === 1 ? 'bg-purple-500' : 'bg-emerald-500'
              }`}
              style={{ width: `${b.assetSharePercentage}%` }}
              title={`${b.name}: ${b.assetSharePercentage}%`}
            />
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-4 pt-1 text-xs font-mono">
          {beneficiaries.map((b, i) => (
            <div key={b.id} className="flex items-center gap-2">
              <span className={`w-3 h-3 rounded-full ${
                i === 0 ? 'bg-amber-500' : i === 1 ? 'bg-purple-500' : 'bg-emerald-500'
              }`} />
              <span className="text-white font-semibold">{b.name}:</span>
              <span className="text-slate-400">{b.assetSharePercentage}%</span>
            </div>
          ))}
        </div>
      </div>

      {/* Beneficiaries Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {beneficiaries.map((ben) => (
          <div key={ben.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-mono text-amber-400 uppercase font-bold">{ben.relationship}</span>
                <h3 className="text-base font-bold text-white font-serif">{ben.name}</h3>
                <p className="text-xs text-slate-400 font-mono mt-0.5">{ben.email}</p>
              </div>

              <div className="px-3 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-300 font-mono font-bold text-sm rounded-xl">
                {ben.assetSharePercentage}%
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-800 text-xs">
              <span className="text-slate-400 font-mono text-[10px] uppercase">Assigned Digital Assets:</span>
              <div className="space-y-1">
                {ben.assignedAssetLabels.map((item, idx) => (
                  <div key={idx} className="bg-slate-800/60 p-2 rounded-lg text-slate-200 font-medium text-[11px] flex items-center justify-between">
                    <span>{item}</span>
                    <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 text-xs text-slate-400 font-mono flex items-center justify-between">
              <span>Key Shards Held: {ben.shardCountAssigned}</span>
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Verified Target
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Designated Heartbeat Verifiers */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-bold text-white font-serif">Dead Man's Switch Heartbeat Trustees ({verifiers.length})</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">Grace Period: 14 Days</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {verifiers.map((v) => (
            <div key={v.id} className="bg-slate-800/50 border border-slate-700/60 rounded-2xl p-4 flex items-center justify-between gap-3 text-xs">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-bold text-white">{v.name}</h4>
                  <span className="text-[10px] font-mono text-amber-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-700">
                    {v.relationship}
                  </span>
                </div>
                <div className="text-slate-400 font-mono text-[11px]">{v.email} • {v.phone}</div>
              </div>

              <div className="text-right space-y-1">
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold font-mono">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  HEARTBEAT CONFIRMED
                </span>
                <div className="text-[10px] text-slate-500 font-mono">Shard: {v.assignedShardId}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Beneficiary Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-scaleUp">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white font-serif flex items-center gap-2">
                <Users className="w-4 h-4 text-amber-400" />
                Add Beneficiary
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white text-lg font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Marcus Vance"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Relationship</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Brother"
                    value={relationship}
                    onChange={(e) => setRelationship(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Asset Share %</label>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={percentage}
                    onChange={(e) => setPercentage(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Email Address</label>
                <input
                  type="email"
                  required
                  placeholder="marcus@family.org"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Assigned Specific Assets (Comma separated)</label>
                <input
                  type="text"
                  value={assignedAssets}
                  onChange={(e) => setAssignedAssets(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-amber-500 hover:bg-amber-400 text-slate-950 px-4 py-2 rounded-xl font-bold cursor-pointer shadow-md"
                >
                  Save Beneficiary
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
