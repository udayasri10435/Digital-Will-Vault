export type DMSStatus = 'HEALTHY' | 'WARNING' | 'ACTIVATED';

export interface Verifier {
  id: string;
  name: string;
  email: string;
  phone: string;
  relationship: string;
  hasConfirmedHeartbeat: boolean;
  assignedShardId?: string;
}

export interface DMSConfig {
  status: DMSStatus;
  checkInFrequencyMonths: number; // e.g. 1, 3, 6, 12
  lastCheckIn: string; // ISO string
  nextCheckInDeadline: string; // ISO string
  gracePeriodDays: number; // e.g. 14 days warning before activation
  verifiers: Verifier[];
  isSimulationActive: boolean;
}

export interface MPCShard {
  shardIndex: number;
  holderName: string;
  holderEmail: string;
  shardHash: string; // e.g. "0x8f3a...b91e"
  isDelivered: boolean;
}

export interface DigitalAssetKey {
  id: string;
  label: string;
  category: 'CRYPTO_SEED' | 'CLOUD_PASSWORD' | 'BANK_VAULT' | 'SECURE_NOTE' | 'DOMAIN_KEYS';
  secretContent: string; // Encrypted until unlocked or threshold met
  totalShards: number; // e.g. 3
  threshold: number; // e.g. 2
  shards: MPCShard[];
  beneficiaryName: string;
  createdAt: string;
}

export interface LegacyCapsule {
  id: string;
  beneficiaryName: string;
  relationship: string;
  beneficiaryEmail: string;
  memories: string;
  personalWishes: string;
  tone: string;
  photoUrl?: string;
  voiceName: string; // Gemini voice: 'Kore', 'Puck', 'Fenrir', 'Zephyr', 'Charon'
  generatedScript?: string;
  audioBase64?: string;
  visualCues?: string[];
  isUnlocked: boolean;
  createdAt: string;
}

export interface SubscriptionItem {
  id: string;
  serviceName: string;
  category: 'ENTERTAINMENT' | 'CLOUD_STORAGE' | 'SOFTWARE' | 'FINANCE' | 'FITNESS';
  monthlyCost: number;
  accountEmail: string;
  accountNumber?: string;
  status: 'ACTIVE_MONITORED' | 'CANCEL_QUEUED' | 'AUTO_CANCELLED';
  cancellationNotice?: string;
  iconName: string;
}

export interface FuneralWishList {
  dispositionType: 'CREMATION' | 'GREEN_BURIAL' | 'TRADITIONAL_BURIAL' | 'MEMORIAL_TREE';
  venuePreference: string;
  attireCode: string;
  musicPlaylist: string[];
  charityOfChoice: string;
  eulogyInstructions: string;
  memorialPhotoUrl: string;
  specialRequests: string;
}

export interface BeneficiaryAllocation {
  id: string;
  name: string;
  email: string;
  relationship: string;
  assetSharePercentage: number;
  assignedAssetLabels: string[];
  shardCountAssigned: number;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  type: 'CHECK_IN' | 'VERIFIER_PING' | 'SHARD_CREATED' | 'SIMULATION_TRIGGERED' | 'NOTICE_SENT' | 'SECRET_UNLOCKED';
  message: string;
  severity: 'INFO' | 'WARNING' | 'ALERT';
}
