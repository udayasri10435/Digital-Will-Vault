import { DMSConfig, DigitalAssetKey, LegacyCapsule, SubscriptionItem, FuneralWishList, BeneficiaryAllocation, AuditLog } from '../types';

export const initialDMSConfig: DMSConfig = {
  status: 'HEALTHY',
  checkInFrequencyMonths: 6,
  lastCheckIn: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(), // 14 days ago
  nextCheckInDeadline: new Date(Date.now() + 166 * 24 * 60 * 60 * 1000).toISOString(), // ~5.5 months left
  gracePeriodDays: 14,
  isSimulationActive: false,
  verifiers: [
    {
      id: 'v1',
      name: 'Dr. Aris Thorne',
      email: 'aris.thorne@legacytrust.io',
      phone: '+1 (555) 382-9102',
      relationship: 'Estate Attorney & Executor',
      hasConfirmedHeartbeat: true,
      assignedShardId: 'Shard-01-A'
    },
    {
      id: 'v2',
      name: 'Elena Vance',
      email: 'elena.vance@family.org',
      phone: '+1 (555) 721-4409',
      relationship: 'Spouse & Primary Beneficiary',
      hasConfirmedHeartbeat: true,
      assignedShardId: 'Shard-02-B'
    }
  ]
};

export const initialDigitalAssets: DigitalAssetKey[] = [
  {
    id: 'asset-1',
    label: 'Bitcoin Cold Storage (Ledger Nano X)',
    category: 'CRYPTO_SEED',
    secretContent: 'abandon amount abandon abandon abandon abandon abandon abandon abandon abandon abandon art',
    totalShards: 3,
    threshold: 2,
    beneficiaryName: 'Elena Vance & Sophia Vance',
    createdAt: new Date(Date.now() - 120 * 24 * 60 * 60 * 1000).toISOString(),
    shards: [
      { shardIndex: 1, holderName: 'Dr. Aris Thorne (Attorney)', holderEmail: 'aris.thorne@legacytrust.io', shardHash: '0x7f2a1b9c8d4e3f2019a8b7c6d5e4f3a2', isDelivered: false },
      { shardIndex: 2, holderName: 'Elena Vance (Spouse)', holderEmail: 'elena.vance@family.org', shardHash: '0x9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b', isDelivered: false },
      { shardIndex: 3, holderName: 'Sophia Vance (Daughter)', holderEmail: 'sophia.vance@family.org', shardHash: '0x1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d', isDelivered: false }
    ]
  },
  {
    id: 'asset-2',
    label: 'Master Password Vault (1Password Emergency Kit)',
    category: 'CLOUD_PASSWORD',
    secretContent: 'A3-9X82-KL77-MPC-VAULT-SECRET-KEY-9941',
    totalShards: 3,
    threshold: 2,
    beneficiaryName: 'Elena Vance',
    createdAt: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString(),
    shards: [
      { shardIndex: 1, holderName: 'Dr. Aris Thorne', holderEmail: 'aris.thorne@legacytrust.io', shardHash: '0x3f4e5d6c7b8a9f0e1d2c3b4a5f6e7d8c', isDelivered: false },
      { shardIndex: 2, holderName: 'Elena Vance', holderEmail: 'elena.vance@family.org', shardHash: '0x8c7d6e5f4a3b2c1d0f9e8d7c6b5a4f3e', isDelivered: false },
      { shardIndex: 3, holderName: 'Marcus Vance (Brother)', holderEmail: 'marcus.vance@family.org', shardHash: '0x2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e', isDelivered: false }
    ]
  },
  {
    id: 'asset-3',
    label: 'Physical Family Safe Master Combination',
    category: 'BANK_VAULT',
    secretContent: 'Combination: 18 - 34 - 09 | Key Location: Top study bookshelf behind blue atlas',
    totalShards: 2,
    threshold: 2,
    beneficiaryName: 'Elena Vance',
    createdAt: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString(),
    shards: [
      { shardIndex: 1, holderName: 'Elena Vance', holderEmail: 'elena.vance@family.org', shardHash: '0x5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d', isDelivered: false },
      { shardIndex: 2, holderName: 'Dr. Aris Thorne', holderEmail: 'aris.thorne@legacytrust.io', shardHash: '0x0d9c8b7a6f5e4d3c2b1a0f9e8d7c6b5a', isDelivered: false }
    ]
  }
];

export const initialLegacyCapsules: LegacyCapsule[] = [
  {
    id: 'capsule-1',
    beneficiaryName: 'Sophia Vance',
    relationship: 'Daughter',
    beneficiaryEmail: 'sophia.vance@family.org',
    memories: 'Our stargazing trips at Yosemite, teaching you how to ride your first bicycle, and your university graduation day.',
    personalWishes: 'Always trust your intuition, never stop painting, and know that my love is always guiding your steps.',
    tone: 'Inspirational & Deeply Loving',
    photoUrl: 'https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&w=800&q=80',
    voiceName: 'Kore',
    generatedScript: `Dearest Sophia,\n\nIf you are listening to this message, know that I am surrounded by warmth and peace. Looking back at our stargazing nights at Yosemite, I remember your eyes wide with wonder at the galaxy. Hold onto that wonder.\n\nYou have grown into an incredible, courageous woman. Never doubt your creative fire. Every canvas you paint carries a piece of our story.\n\nBe kind to yourself, love fearlessly, and know that whenever you look up at the night sky, I am right there with you.\n\nAll my love forever,\nDad`,
    visualCues: [
      'Soft starry night background transition',
      'Yosemite camp photo overlay',
      'Art palette & paintbrushes soft focus frame',
      'Warm golden handwritten closing signature'
    ],
    isUnlocked: false,
    createdAt: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'capsule-2',
    beneficiaryName: 'Elena Vance',
    relationship: 'Spouse',
    beneficiaryEmail: 'elena.vance@family.org',
    memories: 'Our quiet morning coffees on the balcony, building our home, and 24 years of unwavering laughter and partnership.',
    personalWishes: 'Travel to Kyoto as we always dreamed, surround yourself with garden flowers, and live with peace.',
    tone: 'Heartfelt & Tender',
    photoUrl: 'https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?auto=format&fit=crop&w=800&q=80',
    voiceName: 'Zephyr',
    generatedScript: `My dearest Elena,\n\nThank you for twenty-four years of extraordinary love, patience, and warmth. From our quiet balcony coffees to every storm we weathered together, you have been my anchor.\n\nPlease carry on the trip we planned to Kyoto. Walk through the cherry blossoms and smile, knowing I am walking beside you in spirit.\n\nTake care of our family, but above all, take care of your beautiful heart.\n\nYours always and forever,`,
    visualCues: [
      'Kyoto garden serene morning light',
      'Balcony coffee cups photo fade',
      'Soft cello string melody ambient background',
      'Eternal knot golden seal'
    ],
    isUnlocked: false,
    createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()
  }
];

export const initialSubscriptions: SubscriptionItem[] = [
  {
    id: 'sub-1',
    serviceName: 'Spotify Family Plan',
    category: 'ENTERTAINMENT',
    monthlyCost: 16.99,
    accountEmail: 'user@digitalwill.vault',
    accountNumber: 'SPOT-88192-US',
    status: 'ACTIVE_MONITORED',
    iconName: 'Music'
  },
  {
    id: 'sub-2',
    serviceName: 'Netflix Ultra HD',
    category: 'ENTERTAINMENT',
    monthlyCost: 22.99,
    accountEmail: 'user@digitalwill.vault',
    accountNumber: 'NFLX-99401-CA',
    status: 'ACTIVE_MONITORED',
    iconName: 'Tv'
  },
  {
    id: 'sub-3',
    serviceName: 'AWS Cloud Hosting Infrastructure',
    category: 'SOFTWARE',
    monthlyCost: 145.00,
    accountEmail: 'cloud-admin@digitalwill.vault',
    accountNumber: 'AWS-4810-3392',
    status: 'ACTIVE_MONITORED',
    iconName: 'Cloud'
  },
  {
    id: 'sub-4',
    serviceName: 'Google One 2TB Storage',
    category: 'CLOUD_STORAGE',
    monthlyCost: 9.99,
    accountEmail: 'user@digitalwill.vault',
    accountNumber: 'G1-550912',
    status: 'ACTIVE_MONITORED',
    iconName: 'HardDrive'
  },
  {
    id: 'sub-5',
    serviceName: 'Adobe Creative Cloud All Apps',
    category: 'SOFTWARE',
    monthlyCost: 59.99,
    accountEmail: 'designer@digitalwill.vault',
    accountNumber: 'ADBE-00129-CC',
    status: 'ACTIVE_MONITORED',
    iconName: 'Layers'
  }
];

export const initialFuneralWishes: FuneralWishList = {
  dispositionType: 'MEMORIAL_TREE',
  venuePreference: 'Redwood Sanctuary Park, Pacific Northwest',
  attireCode: 'Warm neutral tones, comfortable casual linens (No black suits)',
  musicPlaylist: [
    'Clair de Lune - Claude Debussy',
    'Spiegel im Spiegel - Arvo Pärt',
    'What a Wonderful World - Louis Armstrong',
    'Harvest Moon - Neil Young'
  ],
  charityOfChoice: 'The Ocean Cleanup Foundation & Local Rainforest Trust',
  eulogyInstructions: 'Keep speeches lighthearted with humorous stories. Celebrate life rather than mourning loss. Serve wood-fired pizza and chai tea afterwards.',
  memorialPhotoUrl: 'https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=800&q=80',
  specialRequests: 'Plant an oak or redwood sapling over my resting place so my energy nourishes new life for generations.'
};

export const initialBeneficiaries: BeneficiaryAllocation[] = [
  {
    id: 'ben-1',
    name: 'Elena Vance',
    relationship: 'Spouse',
    email: 'elena.vance@family.org',
    assetSharePercentage: 50,
    assignedAssetLabels: ['1Password Vault Key', 'Primary Family Safe', '50% Crypto Portfolio'],
    shardCountAssigned: 2
  },
  {
    id: 'ben-2',
    name: 'Sophia Vance',
    relationship: 'Daughter',
    email: 'sophia.vance@family.org',
    assetSharePercentage: 35,
    assignedAssetLabels: ['Digital Photo Archive', '35% Crypto Portfolio', 'Domain Portfolio'],
    shardCountAssigned: 2
  },
  {
    id: 'ben-3',
    name: 'Marcus Vance',
    relationship: 'Brother',
    email: 'marcus.vance@family.org',
    assetSharePercentage: 15,
    assignedAssetLabels: ['Hardware Lab Equipment', '15% Crypto Portfolio'],
    shardCountAssigned: 1
  }
];

export const initialLogs: AuditLog[] = [
  {
    id: 'log-1',
    timestamp: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toLocaleString(),
    type: 'CHECK_IN',
    message: "Owner check-in recorded via secure biometric authentication. DMS timer reset to 6 months.",
    severity: 'INFO'
  },
  {
    id: 'log-2',
    timestamp: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toLocaleString(),
    type: 'SHARD_CREATED',
    message: "MPC Key Shards (2-of-3 threshold) generated for Bitcoin Cold Storage & encrypted with Galois Field polynomial.",
    severity: 'INFO'
  },
  {
    id: 'log-3',
    timestamp: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toLocaleString(),
    type: 'VERIFIER_PING',
    message: "Heartbeat verification confirmed by Trustee Dr. Aris Thorne (Estate Attorney).",
    severity: 'INFO'
  }
];
