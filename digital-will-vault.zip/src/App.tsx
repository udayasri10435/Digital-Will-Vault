import React, { useState } from 'react';
import { Header } from './components/Header';
import { OverviewDashboard } from './components/OverviewDashboard';
import { MpcKeyVault } from './components/MpcKeyVault';
import { LegacyCapsules } from './components/LegacyCapsules';
import { SubscriptionCanceller } from './components/SubscriptionCanceller';
import { FuneralWishes } from './components/FuneralWishes';
import { BeneficiariesMatrix } from './components/BeneficiariesMatrix';

import {
  initialDMSConfig,
  initialDigitalAssets,
  initialLegacyCapsules,
  initialSubscriptions,
  initialFuneralWishes,
  initialBeneficiaries,
  initialLogs,
} from './data/mockData';

import { DMSConfig, DigitalAssetKey, LegacyCapsule, SubscriptionItem, FuneralWishList, BeneficiaryAllocation, AuditLog } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  const [dmsConfig, setDmsConfig] = useState<DMSConfig>(initialDMSConfig);
  const [assets, setAssets] = useState<DigitalAssetKey[]>(initialDigitalAssets);
  const [capsules, setCapsules] = useState<LegacyCapsule[]>(initialLegacyCapsules);
  const [subscriptions, setSubscriptions] = useState<SubscriptionItem[]>(initialSubscriptions);
  const [funeralWishes, setFuneralWishes] = useState<FuneralWishList>(initialFuneralWishes);
  const [beneficiaries, setBeneficiaries] = useState<BeneficiaryAllocation[]>(initialBeneficiaries);
  const [logs, setLogs] = useState<AuditLog[]>(initialLogs);

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const addAuditLog = (message: string, type: AuditLog['type'] = 'CHECK_IN', severity: AuditLog['severity'] = 'INFO') => {
    const newLog: AuditLog = {
      id: 'log-' + Date.now(),
      timestamp: new Date().toLocaleString(),
      type,
      message,
      severity
    };
    setLogs((prev) => [newLog, ...prev]);
  };

  // Ping "I'm Alive" Check-in Action
  const handleCheckInPing = () => {
    const now = new Date();
    const months = dmsConfig.checkInFrequencyMonths || 6;
    const nextDeadline = new Date(now.getTime() + months * 30 * 24 * 60 * 60 * 1000);

    setDmsConfig((prev) => ({
      ...prev,
      status: 'HEALTHY',
      lastCheckIn: now.toISOString(),
      nextCheckInDeadline: nextDeadline.toISOString(),
      isSimulationActive: false
    }));

    addAuditLog('Owner check-in recorded via biometric ping. Dead Man\'s Switch timer reset to 6 months.', 'CHECK_IN', 'INFO');
    showToast('Ping Confirmed! Dead Man\'s Switch timer reset for another 6 months.');
  };

  // Toggle Test Execution Simulation
  const handleToggleSimulation = () => {
    const nextState = !dmsConfig.isSimulationActive;
    setDmsConfig((prev) => ({
      ...prev,
      isSimulationActive: nextState,
      status: nextState ? 'ACTIVATED' : 'HEALTHY'
    }));

    if (nextState) {
      addAuditLog('Dead Man\'s Switch EXPIRED in Simulation Mode. Posthumous execution protocols triggered.', 'SIMULATION_TRIGGERED', 'ALERT');
      showToast('Vault Execution Simulation Started! All legacy capsules and MPC shards unlocked for testing.');
    } else {
      addAuditLog('Simulation Mode exited. Vault returned to active Dead Man\'s Switch monitoring.', 'CHECK_IN', 'INFO');
      showToast('Simulation Exited. Vault is healthy and monitoring.');
    }
  };

  const handleAddAsset = (asset: DigitalAssetKey) => {
    setAssets((prev) => [asset, ...prev]);
    showToast(`Vaulted key: "${asset.label}"`);
  };

  const handleAddCapsule = (capsule: LegacyCapsule) => {
    setCapsules((prev) => [capsule, ...prev]);
    showToast(`AI Legacy Capsule generated for ${capsule.beneficiaryName}`);
  };

  const handleAddSubscription = (sub: SubscriptionItem) => {
    setSubscriptions((prev) => [...prev, sub]);
    showToast(`Monitored subscription added: ${sub.serviceName}`);
  };

  const handleUpdateSubStatus = (id: string, status: SubscriptionItem['status']) => {
    setSubscriptions((prev) =>
      prev.map((s) => (s.id === id ? { ...s, status } : s))
    );
  };

  const handleAddBeneficiary = (ben: BeneficiaryAllocation) => {
    setBeneficiaries((prev) => [...prev, ben]);
    showToast(`Beneficiary added: ${ben.name}`);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans antialiased selection:bg-amber-500 selection:text-slate-950">
      
      {/* Toast Popup Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-amber-500/50 text-slate-100 px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-slideUp text-xs font-semibold">
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main App Header */}
      <Header
        dmsConfig={dmsConfig}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onCheckIn={handleCheckInPing}
        onToggleSimulation={handleToggleSimulation}
      />

      {/* Main Workspace Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dashboard' && (
          <OverviewDashboard
            dmsConfig={dmsConfig}
            assets={assets}
            capsules={capsules}
            subscriptions={subscriptions}
            funeralWishes={funeralWishes}
            logs={logs}
            onCheckIn={handleCheckInPing}
            onToggleSimulation={handleToggleSimulation}
            setActiveTab={setActiveTab}
          />
        )}

        {activeTab === 'mpc-vault' && (
          <MpcKeyVault
            assets={assets}
            isActivated={dmsConfig.status === 'ACTIVATED' || dmsConfig.isSimulationActive}
            onAddAsset={handleAddAsset}
            onAuditLog={(msg, type) => addAuditLog(msg, type, 'INFO')}
          />
        )}

        {activeTab === 'legacy-capsules' && (
          <LegacyCapsules
            capsules={capsules}
            isActivated={dmsConfig.status === 'ACTIVATED' || dmsConfig.isSimulationActive}
            onAddCapsule={handleAddCapsule}
            onAuditLog={(msg, type) => addAuditLog(msg, type, 'INFO')}
          />
        )}

        {activeTab === 'subscriptions' && (
          <SubscriptionCanceller
            subscriptions={subscriptions}
            isActivated={dmsConfig.status === 'ACTIVATED' || dmsConfig.isSimulationActive}
            onAddSubscription={handleAddSubscription}
            onUpdateStatus={handleUpdateSubStatus}
            onAuditLog={(msg, type) => addAuditLog(msg, type, 'INFO')}
          />
        )}

        {activeTab === 'funeral-wishes' && (
          <FuneralWishes
            wishes={funeralWishes}
            onUpdateWishes={(w) => setFuneralWishes(w)}
            onAuditLog={(msg, type) => addAuditLog(msg, type, 'INFO')}
          />
        )}

        {activeTab === 'beneficiaries' && (
          <BeneficiariesMatrix
            beneficiaries={beneficiaries}
            verifiers={dmsConfig.verifiers}
            onAddBeneficiary={handleAddBeneficiary}
            onAuditLog={(msg, type) => addAuditLog(msg, type, 'INFO')}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-500 text-xs py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 text-center space-y-2">
          <p className="font-mono text-slate-400">
            Digital Will Vault • Multi-Party Computation & Autonomous Legacy System • Powered by Google Gemini AI
          </p>
          <p className="text-[11px] text-slate-600">
            All key shards protected by 256-bit zero-knowledge threshold cryptography.
          </p>
        </div>
      </footer>

    </div>
  );
}
